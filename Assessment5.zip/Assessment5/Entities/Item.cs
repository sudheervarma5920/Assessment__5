﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlTypes;

namespace Assessment5.Entities
{
    public class Item
    {
        [Key]
        [Column(TypeName = "char")]
        [StringLength(4)]
        public string ITCODE { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(15)]
        public string ITDESC { get; set; }
        public int ITRATE { get; set; }
    }
}
