﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment5.Migrations
{
    /// <inheritdoc />
    public partial class pops : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    ITCODE = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    ITDESC = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    ITRATE = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.ITCODE);
                });

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    Suplno = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    SupplName = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    SupLAddr = table.Column<string>(type: "varchar(40)", maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.Suplno);
                });

            migrationBuilder.CreateTable(
                name: "Pomasters",
                columns: table => new
                {
                    pono = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ITCODE = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    SuplNo = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pomasters", x => x.pono);
                    table.ForeignKey(
                        name: "FK_Pomasters_Items_ITCODE",
                        column: x => x.ITCODE,
                        principalTable: "Items",
                        principalColumn: "ITCODE",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pomasters_Suppliers_SuplNo",
                        column: x => x.SuplNo,
                        principalTable: "Suppliers",
                        principalColumn: "Suplno",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_ITCODE",
                table: "Pomasters",
                column: "ITCODE");

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_SuplNo",
                table: "Pomasters",
                column: "SuplNo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pomasters");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
